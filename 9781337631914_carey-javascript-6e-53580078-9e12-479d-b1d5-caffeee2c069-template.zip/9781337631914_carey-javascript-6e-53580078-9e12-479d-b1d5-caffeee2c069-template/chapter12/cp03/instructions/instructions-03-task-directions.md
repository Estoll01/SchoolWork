## Task 03

Create an event handler that runs the `makeTree()` function when the page loads.
