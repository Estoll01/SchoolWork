**Task #03:** Create an event handler to run `makeTree()` when the page loads
