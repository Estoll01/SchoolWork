Open the _js_nodes_txt.html_ and _js_tree_txt.js_ files. Enter **your name** and **the date** in the comment section of each file, and rename them as _js_nodes.html_ and _js_tree.js_ respectively.

## Task 01

Go to the _js_nodes.html_ file in your editor. Within the document head, create links to the _js_tree.css_ style sheet file and the _js_tree.js_ JavaScript file. Load the _js_tree.js_ file asynchronously.
