## Task 06

Return to the `makeTree()` function and add commands to display the total count of nodes, element nodes, text nodes, and whitespace nodes within the `span` elements whose `id`s are “`totalNodes`”, “`elemNodes`”, “`textNodes`”, and “`wsNodes`”, respectively.
