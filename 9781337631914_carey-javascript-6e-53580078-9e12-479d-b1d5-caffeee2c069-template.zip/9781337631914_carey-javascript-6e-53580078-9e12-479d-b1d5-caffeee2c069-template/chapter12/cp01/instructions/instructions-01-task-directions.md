Open the _na_home_txt.html_ and _na_styler_txt.js_ files. Enter **your name** and **the date** in the comment section of each file, and rename them as _na_home.html_ and _na_styler.js_ respectively.

## Task 01

Go to the _na_home.html_ file in your editor. Go to the document head and add a `script` element for the _na_styler.js_ file. Load the file asynchronously.
