**Task #03:** Declare the `styleNum` variable equal to the value of `randint(5)`
