## Task 03

Create the `setStyles()` function using the commands listed in the steps below. Christine wants one of five fancy style sheets to be randomly used when the page is opened. Declare the `styleNum` variable equal to the value returned by the `randInt()` function, using **5** as the parameter value.
