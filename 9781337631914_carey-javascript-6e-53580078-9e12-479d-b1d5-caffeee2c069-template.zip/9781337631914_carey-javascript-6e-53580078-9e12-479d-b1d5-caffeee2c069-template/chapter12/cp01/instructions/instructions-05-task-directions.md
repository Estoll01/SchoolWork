## Task 05

Christine wants users to be able to choose between the five fancy style sheet themes she has created by clicking thumbnail images from a figure box. Create an element node named `figBox` for the `figure` element. Set its `id` attribute to “styleThumbs” and append it to the `div` element with the ID “box”.
