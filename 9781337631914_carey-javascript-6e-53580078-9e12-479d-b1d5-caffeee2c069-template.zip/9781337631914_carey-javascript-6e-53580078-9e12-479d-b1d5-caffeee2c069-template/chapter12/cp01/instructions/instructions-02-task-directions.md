## Task 02
Go to the *na_styler.js* file in your editor. Add an event listener that runs the `setStyles()` function when the page loads.
