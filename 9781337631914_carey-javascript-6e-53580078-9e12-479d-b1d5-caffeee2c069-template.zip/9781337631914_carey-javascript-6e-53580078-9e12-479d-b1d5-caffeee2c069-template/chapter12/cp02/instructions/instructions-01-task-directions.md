Open the _sub_menu_txt.html_ and _sub_cart_txt.js_ files. Enter **your name** and **the date** in the comment section of each file, and rename them as _sub_menu.html_ and _sub_cart.js_ respectively.

## Task 01

Go to the _sub_menu.html_ file in your editor. Add a `script` element to the document `head` for the _sub_cart.js_ file, loading it asynchronously. Take some time to study the contents and structure of the file and then save your changes.
