## Task 03

Create the `setupCart()` function. The purpose of this function is to define the event handlers for the Add to Order buttons on the page. Add the following commands to the function:

- Create a variable named `addButtons`, which contains the collection of elements belonging to the `addButton` class.

- Loop through the `addButtons` collection and for each button, add an event handler that runs the `addItem()` function when the button is clicked.
