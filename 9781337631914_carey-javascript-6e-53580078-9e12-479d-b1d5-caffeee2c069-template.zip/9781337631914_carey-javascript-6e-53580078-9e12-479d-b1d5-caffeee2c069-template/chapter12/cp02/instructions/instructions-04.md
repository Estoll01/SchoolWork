**Task #04:** Create the `addItem()` function
