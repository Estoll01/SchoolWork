**Task #02:** Add an event listener to run `setupCart` when the page is loaded
