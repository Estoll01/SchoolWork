## Task 02

Return to the _sub_cart.js_ file in your editor. Add an event listener that runs the `setupCart()` function when the page is loaded.
