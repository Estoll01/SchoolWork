**Task #03:** Create the `setupCart()` function
