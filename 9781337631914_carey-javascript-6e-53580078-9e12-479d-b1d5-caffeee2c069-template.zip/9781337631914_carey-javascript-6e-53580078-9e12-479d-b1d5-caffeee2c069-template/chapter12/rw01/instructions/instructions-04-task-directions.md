## Task 04

Go to the _bc_keys.js_ file in your editor. Add event listeners to run the `findKeyWords()` and `makeKeyStyles()` functions when the page is loaded.
