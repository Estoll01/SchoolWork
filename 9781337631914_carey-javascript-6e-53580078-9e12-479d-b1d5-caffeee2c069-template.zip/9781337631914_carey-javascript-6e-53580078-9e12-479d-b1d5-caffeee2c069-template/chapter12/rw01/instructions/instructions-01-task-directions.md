Open the _bc_fed_txt.html_ and _bc_keys_txt.js_ files. Enter **your name** and **the date** in the comment section of each file, and rename them as _bc_fed.html_ and _bc_keys.js_ respectively.

## Task 01

Go to the _bc_fed.html_ file in your editor. Directly above the closing `</head>` tag, link the page to the _bc_keys.js_ JavaScript file, loading the file asynchronously. Take some time to study the contents of the HTML file and then close it, saving your changes.
