**Task #04:** Create the `defineDataArray()` function
