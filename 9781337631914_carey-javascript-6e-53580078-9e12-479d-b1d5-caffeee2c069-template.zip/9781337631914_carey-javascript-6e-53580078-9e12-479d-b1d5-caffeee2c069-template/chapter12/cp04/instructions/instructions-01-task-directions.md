Open the _gi_qbs_txt.html_ and _gi_sort_txt.js_ files. Enter **your name** and **the date** in the comment section of each file, and save them as _gi_qbs.html_ and _gi_sort.js_ respectively.

## Task 01

Go to the _gi_qbs.html_ file in your editor. Within the document head, create a link to the _gi_sort.js_ JavaScript file, loading the file asynchronously.

Scroll down the file and locate the web table containing the quarterback statistics. Add a class attribute to the opening `<table>` tag with the value “sortable” to indicate that this table can be sorted by the user.
