## Task 02

Go to the _gi_sort.js_ file in your editor.

Below the initial comment section, declare the following global variables:

- The empty array `tableData`, which will store the data values in the web table

- The empty array `dataCategories`, which will store the text of the column headings

- The `sortIndex` variable, which will store the index number of the table column used for sorting; set its initial value to **0** (the first table column)

- The `sortDirection` variable, which will store whether the column is sorted in ascending order (1) or descending order (-1); set its initial value to **1** (to sort in ascending order)
