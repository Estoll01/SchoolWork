## Task 03

Add an event listener that runs an anonymous function when the page is loaded. Within the anonymous function, call and run the `defineDataArray()` and `writeTableData()` functions.
