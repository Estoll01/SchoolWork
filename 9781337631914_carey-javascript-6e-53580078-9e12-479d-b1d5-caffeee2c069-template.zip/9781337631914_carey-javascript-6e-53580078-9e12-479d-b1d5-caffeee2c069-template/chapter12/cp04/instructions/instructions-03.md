**Task #03:** Add an event listener for when the page loads
