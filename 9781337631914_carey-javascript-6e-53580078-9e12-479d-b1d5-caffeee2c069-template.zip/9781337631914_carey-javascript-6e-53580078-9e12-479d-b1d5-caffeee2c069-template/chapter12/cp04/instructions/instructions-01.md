**Task #01:** Loaded files and added attributes correctly
