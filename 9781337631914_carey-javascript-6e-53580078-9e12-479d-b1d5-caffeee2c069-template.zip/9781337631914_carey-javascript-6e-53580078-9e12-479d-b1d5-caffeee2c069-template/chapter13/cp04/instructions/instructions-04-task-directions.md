## Task 04

Apply the `toLowerCase()` method to `wordContent` to change all the words to lowercase.
