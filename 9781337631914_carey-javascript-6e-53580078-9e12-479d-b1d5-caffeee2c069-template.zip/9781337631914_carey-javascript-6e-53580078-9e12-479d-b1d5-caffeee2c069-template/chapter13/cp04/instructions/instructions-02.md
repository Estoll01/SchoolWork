**Task #02:** Declare `wordContent` variable containing the text content of the speech `div` element
