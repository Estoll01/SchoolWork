**Task #13:** Sort the `uniqueWords` variable alphabetically
