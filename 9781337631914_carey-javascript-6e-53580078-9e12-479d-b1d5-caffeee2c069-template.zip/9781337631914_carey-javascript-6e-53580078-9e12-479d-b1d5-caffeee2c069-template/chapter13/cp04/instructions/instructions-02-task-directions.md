Go to the _ws_cloud.js_ file. Directly below the comment section, insert an event listener for the windows load event. Have the event listener run the anonymous function containing the commands described in the following tasks.

## Task 02 and Task 03

Declare the `wordContent` variable containing the text content of the speech `div` element, using the `textContent` property to retrieve only the speech text and not any of the HTML tags in the element.
