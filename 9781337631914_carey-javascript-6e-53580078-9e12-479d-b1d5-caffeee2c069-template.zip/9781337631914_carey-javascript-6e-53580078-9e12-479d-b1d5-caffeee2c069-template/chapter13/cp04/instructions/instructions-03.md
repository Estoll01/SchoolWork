**Task #03:** Words are formatted and displayed correctly in word cloud
