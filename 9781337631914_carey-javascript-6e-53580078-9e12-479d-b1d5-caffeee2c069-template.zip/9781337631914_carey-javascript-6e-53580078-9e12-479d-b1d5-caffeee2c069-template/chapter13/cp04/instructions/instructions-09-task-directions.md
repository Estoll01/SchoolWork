## Task 09

Professor Cho has supplied you with the `findUnique()` function, which creates an array of unique values in a given array, returning a 2-dimensional array of the form

```
array[i][j]
```

where

```
Array[i][0]
```

displays the text of the i<sup>th</sup> word, while

```
Array[i][1]
```

displays the count or number of times the i<sup>th</sup> word is used in the text.

Call the `findUnique()` function with the `wordArray` variable as the parameter value and store the 2-dimensional array of unique words and their counts in the `uniqueWords` array.
