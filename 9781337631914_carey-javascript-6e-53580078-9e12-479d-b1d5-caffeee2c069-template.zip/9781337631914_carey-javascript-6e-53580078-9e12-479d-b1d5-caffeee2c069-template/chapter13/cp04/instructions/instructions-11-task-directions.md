## Task 11

Professor Cho wants only the top 100 words displayed in the word count. Reduce the length of the `uniqueWords` array to 100.

To format the words in the word cloud you will need to know the count for the least-used word. Store the count of the least-used word in the `minimumCount` variable.

> Hint: Use the reference `uniqueWords[99][1]`.
