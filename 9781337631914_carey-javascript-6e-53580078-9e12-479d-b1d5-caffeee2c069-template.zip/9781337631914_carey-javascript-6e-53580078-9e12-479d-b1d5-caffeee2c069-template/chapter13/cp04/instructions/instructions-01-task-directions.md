Use your editor to open the _ws_lincoln_txt.html_ and _ws_cloud_txt.js_ files. Enter **your name** and **the date** in the comment section of each file, and rename them as _ws_lincoln.html_ and _ws_cloud.js_ respectively.

## Task 01

Go to the _ws_lincoln.html_ file in your editor. Link the page to the _ws_cloud.css_ style sheet and the _ws_stopwords.js_ and _ws_clouds.js_ JavaScript files (in that order). Load the JavaScript files asynchronously.

Study the contents of the file. Lincoln’s speech is stored in a `div` element with the ID “speech”. The word cloud text will be placed in the aside element with the ID “cloud”.
