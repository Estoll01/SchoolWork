## Task 12

Professor Cho wants the top-three words highlighted in the word count. Store the count of the third highest-used word in the `top3Count` variable.

> Hint: Use the reference `uniqueWords[2][1]`.
