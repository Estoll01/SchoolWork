## Task 08

Apply the `split()` method to split `wordContent` at every occurrence of one or more white-space characters. Save the array of words in the `wordArray` variable.

Professor Cho has supplied you with the `findUnique()` function, which creates an array of unique values in a given array, returning a 2-dimensional array of the form
