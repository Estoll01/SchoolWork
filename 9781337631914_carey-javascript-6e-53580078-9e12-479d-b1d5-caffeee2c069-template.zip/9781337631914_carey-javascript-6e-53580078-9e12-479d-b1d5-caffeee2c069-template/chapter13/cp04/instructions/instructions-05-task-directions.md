## Task 05 and Task 06

Use the regular expression `/[!\.,:;\?\’”\(\)\{\}\d\-]/` and the `replace()` method to replace punctuation characters and digits with empty text strings.

> Hint: Use the `g` flag in your regular expression to apply the search globally.
