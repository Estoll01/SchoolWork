## Task 7

There may be blank spaces at the beginning and end of the text in the `wordContent` variable. Apply the `trim()` method to remove excess blank spaces.
