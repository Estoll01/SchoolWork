## Task 10

Sort the contents of the `uniqueWords` array in decreasing order of word count, using the `sortByCount()` function as the compare function for the `sort()` method.
