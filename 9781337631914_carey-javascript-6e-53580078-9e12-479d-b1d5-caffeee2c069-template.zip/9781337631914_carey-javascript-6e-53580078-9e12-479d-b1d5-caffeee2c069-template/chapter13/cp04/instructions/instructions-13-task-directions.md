## Task 13

The word cloud should list the words alphabetically. Sort the `uniqueWords` variable alphabetically by applying the `sortByWord()` function as the compare function.
