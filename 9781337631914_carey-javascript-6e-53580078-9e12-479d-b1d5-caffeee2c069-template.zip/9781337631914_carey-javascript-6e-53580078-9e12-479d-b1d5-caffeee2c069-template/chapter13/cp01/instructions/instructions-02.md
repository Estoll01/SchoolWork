**Task #02:** Create `onchange` event handlers in the window `load` event
