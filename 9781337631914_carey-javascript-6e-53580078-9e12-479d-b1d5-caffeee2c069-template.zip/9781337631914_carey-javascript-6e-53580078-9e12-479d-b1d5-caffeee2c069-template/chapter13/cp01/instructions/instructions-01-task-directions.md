Open the _mpl_links_txt.html_ and _mp_links_txt.js_ files. Enter **your name** and **the date** in the comment section of each file, and rename them as _mpl_links.html_ and _mpl_links.js_ respectively.

## Task 01

Go to the _mpl_links.html_ file in your editor. Within the document head, add a `script` element for the _mpl_links.js_ file. Load the file asynchronously. Take some time to study the content of the file. Note that the selection lists are placed within a `form` element named “govLinks”.
