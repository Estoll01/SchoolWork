Verify that you can load different government websites by selecting the website name from the entries in the four selection lists.
