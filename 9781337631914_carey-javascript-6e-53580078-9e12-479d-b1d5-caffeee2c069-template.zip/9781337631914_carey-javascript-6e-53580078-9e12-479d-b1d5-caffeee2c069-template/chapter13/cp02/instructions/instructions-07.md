Verify the following:

You cannot submit the form without adding a travel summary, a name, a social security number, and account, department, and project IDs in the correct format.

If you fail to enter a travel summary, the customized message, “You must include a summary of the trip in your report.” is displayed.

When you enter or change values in the expense report table, the column and row totals are automatically updated and the column and row totals are formatted to 2 decimals places with a thousands separator. The overall travel expense total should be shown in currency format. (Note: At the time of this writing, Firefox does not support the date data type, so you will not see the mm/dd/yyyy value in the travel date column.)
