## Task 06

Scroll down to the `empInfo` table and add pattern attributes to the following fields using regular expressions (Note: Regular expressions in the HTML pattern attribute do not include the opening and closing / character):

- The accID field should consist only of the letters “ACT” followed by exactly 6 digits.

- The deptID field should consist only of the letters “DEPT” followed by 4 to 6 digits.

- The projID field should consist only of the letters “PROJ” followed by a dash and then two lowercase letters followed by another dash and 3 digits.

- The ssn field should consist only of 3 digits followed by a dash followed by 2 more digits followed by a dash, ending with 4 more digits.
