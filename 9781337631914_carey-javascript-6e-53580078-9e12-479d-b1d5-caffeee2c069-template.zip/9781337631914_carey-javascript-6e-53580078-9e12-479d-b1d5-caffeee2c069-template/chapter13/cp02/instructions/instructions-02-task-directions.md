## Task 02

Kay wants a customized validation message if employees neglect to fill out the summary field that provides a summary of the travel expenses. Create the `validateSummary()` function that displays the message **“You must include a summary of the trip in your report.”** if the validation state of the summary field value is missing; otherwise set the custom validation message to an empty text string.
