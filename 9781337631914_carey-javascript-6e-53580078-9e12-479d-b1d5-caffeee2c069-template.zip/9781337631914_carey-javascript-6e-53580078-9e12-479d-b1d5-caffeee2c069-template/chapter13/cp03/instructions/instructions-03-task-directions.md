## Task 03

Create the `sessionTest()` function. The purpose of this function is to provide a validation test for the conference session selection list. Add the following commands to the function:

- Test whether the selected index of the `sesssionBox` selection list is equal to **-1**. If it is, the user has not selected a session package. Display the custom validation message “Select a Session Package”.

If the selected index is equal to **-1** set the custom validation message to an empty text string.
