## Task 05

Display the values of the session storage variables in the current web page by creating the `writeSessionValues()` function, adding the following commands:

- Set the text content of `span` elements with the IDs “regName”, “regGroup”, “regEmail”, “regPhone”, “regSession”, “regBanquet”, and “regPack”, to the values of the session storage variables, `confName`, `confGroup`, `confMail`, `confPhone`, `confSession`, `confBanquet`, and `confPack`.

Set the text content of the `span` element with the ID “regTotal” to the value `$total` where total is the value of the `confTotal` session storage variable.
