**Task #07:** Copy and paste `writeSessionValues()` function into _mas_reg2.js_
