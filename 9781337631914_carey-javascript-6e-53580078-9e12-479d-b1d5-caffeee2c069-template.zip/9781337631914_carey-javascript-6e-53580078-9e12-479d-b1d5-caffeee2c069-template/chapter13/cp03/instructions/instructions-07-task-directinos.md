## Task 07

Open the _mas_reg2.js_ file in your editor. Directly below the comment section, copy and paste the `writeSessionValues()` function from the _mas_register.js_ file.

Add an event listener that runs the `writeSessionValues()` variable when the page loads.
