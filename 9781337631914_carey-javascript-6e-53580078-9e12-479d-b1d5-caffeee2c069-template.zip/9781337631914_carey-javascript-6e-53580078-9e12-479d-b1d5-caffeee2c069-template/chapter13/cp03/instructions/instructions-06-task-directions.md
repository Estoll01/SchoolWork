## Task 06

Open the _mas_reg2.html_ file in your editor. Add a `script` element for the _mas_reg2.js_ file. Load the file asynchronously.
