Verify the following:

- Values and selected options from the registration form are automatically displayed in the page as you tab from one control element to the next.

- You cannot submit the form unless a conference session packet has been selected.

- When the form is submitted, the browser displays the content of the _mas_reg2.html_ file with the user’s choices automatically retrieved from the session storage variables and displayed at the top of the page.
