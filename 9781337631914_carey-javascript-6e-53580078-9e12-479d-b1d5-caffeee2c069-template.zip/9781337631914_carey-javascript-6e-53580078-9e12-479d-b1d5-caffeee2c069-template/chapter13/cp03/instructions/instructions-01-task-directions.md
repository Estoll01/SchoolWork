Use your editor to open the _mas_register_txt.html_, _mas_register_txt.js_, _mas_reg2_txt.html_, and _mas_reg2_txt.js_ files. Enter **your name** and **the date** in the comment section of each file, and rename them as _mas_register.html_, _mas_register.js_, _mas_reg2.html_, and _mas_reg2.js_ respectively.

## Task 01

Go to the _mas_register.html_ file in your editor. Add a `script` element for the _mas_register.js_ file. Load the file asynchronously.

Take some time to study the contents of the file, taking note of the field names and IDs assigned to different form controls.
