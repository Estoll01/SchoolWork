**Task #02:** window `load` event listener created in _mas_register_
