## Task 02

Return to the _mas_register.js_ file in your editor. Directly below the initial comment section, insert an event listener for the window load event. Run an anonymous function in response to the event containing the following commands:

- Call the `calcCart()` function (which you will create shortly).

- Create an `onclick` event handler for the `regSubmit` button that runs the `sessionTest()` function when the button is clicked.

- Create `onblur` event handlers for the input boxes with the IDs: "fnBox", "lnBox", "groupBox", "mailBox", "phoneBox", and "banquetBox", running the `calcCart()` function in response to each event.

- Create an `onchange` event handler for the `sessionBox` selection list, running the `calcCart()` function when the selection list is changed.

- Create an `onclick` event handler for the `mediaCB` check box, running the `calcCart()` function in response.
