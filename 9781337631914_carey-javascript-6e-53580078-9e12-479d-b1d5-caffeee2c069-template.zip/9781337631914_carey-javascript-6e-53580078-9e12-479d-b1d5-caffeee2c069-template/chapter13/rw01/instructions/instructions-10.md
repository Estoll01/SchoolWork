The remaining functions have already been entered for you.

Return to the _co_cart.html_ file in your browser and enter a sample customer order and click the "Checkout" button to submit the order and load the _co_credit.html_ file. Verify the following:

- The field values from the customer order are displayed in the order form.

- You cannot submit the payment unless you entered the name of the card holder, selected a credit card company, entered a valid credit card number (you can find lists of sample test credit card numbers on the web), entered a valid expiration date, and entered a valid CVC number.
