**Task #08:** `runSubmit()` function calls the validate functions
