**Task #02:** window `load` event listener added in _co_cart.js_
