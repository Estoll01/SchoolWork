## Task 07

Add another event listener for the window load event that runs different validation event handlers when the page is loaded by the browser. Add code to the anonymous function for the load event that does the following:

- Runs the `runSubmit()` function when the `subButton` is clicked.

- Runs the `validateName()` function when a value is input into the `cardHolder` field.

- Runs the `validateNumber()` function when a value is input into the `cardNumber` field.

- Runs the `validateDate()` function when a value is input into the `expDate` field.

- Runs the `validateCVC()` function when a value is input into the `cvc` field.
