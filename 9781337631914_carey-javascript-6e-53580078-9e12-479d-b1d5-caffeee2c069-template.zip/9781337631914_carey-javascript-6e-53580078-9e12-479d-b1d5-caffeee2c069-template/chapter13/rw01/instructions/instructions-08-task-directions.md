## Task 08

Create the `runSubmit()` function that is run when the form is submitted. Within the function, add commands to run the `validateName()`, `validateCredit()`, `validateNumber()`, `validateDate()`, and `validateCVC()` functions.
