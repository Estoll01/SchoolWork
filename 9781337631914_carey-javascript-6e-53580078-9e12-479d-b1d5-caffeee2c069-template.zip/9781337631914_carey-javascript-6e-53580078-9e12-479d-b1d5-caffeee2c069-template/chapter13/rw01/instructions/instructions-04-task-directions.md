## Task 04

Go to the _co_cart.html_ and link the page to the _co_cart.js_ file, loading the file asynchronously. Study the contents of the file and the cart form. Take note of the field names and IDs of the files in the form.
