Use your editor to open the _co_cart_txt.html_, _co_cart_txt.js_, _co_credit_txt.html_, and _co_credit_txt.js_ files. Enter **your name** and **the date** in the comment section of each file, and save them as _co_cart.html_, _co_cart.js_, _co_credit.html_, and _co_credit.js_ respectively.

## Task 01:

Go to the _co_cart.html_ file in your editor. Within the <form> tag for the cart form, add attributes to open the _co_credit.html_ file using the `get` method when the cart form is submitted.
