## Task 02 and Task 03

Go to the _co_cart.js_ file in your editor. Directly below the initial comment section, add an event listener for the window load event that does the following when the page is loaded:

- Runs the `calcCart()` function.

- Runs the `calcCart()` function when the field value is changed.

> Hint: Apply an `onchange` event handler to the `modelQty` field in the cart form.

- Uses a for loop that loops through every option in the group of shipping option buttons, adding an event handler to run the `calcCart()` function when each option button is clicked.
