**Task #03:** `calcCart()` function implemented correctly
