**Task #04:** Load _co_cart.js_ asynchronously in _co_cart.html_
