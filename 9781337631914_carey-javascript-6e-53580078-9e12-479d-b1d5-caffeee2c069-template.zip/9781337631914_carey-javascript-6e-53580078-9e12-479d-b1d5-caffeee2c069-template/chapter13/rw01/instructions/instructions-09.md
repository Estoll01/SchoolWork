**Task #09:**`validateDate()` function implemented correctly
