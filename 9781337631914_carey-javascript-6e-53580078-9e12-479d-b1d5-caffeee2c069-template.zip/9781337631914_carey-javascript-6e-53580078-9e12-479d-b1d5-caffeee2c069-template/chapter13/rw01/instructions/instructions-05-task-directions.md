Verify that the page correctly calculates and displays the total cost of the order as shown in _Figure 13-63_ and that the totals are automatically updated as you change the order options.

## Task 05

Go to the _co_credit.html_ file in your editor. Link the page to the _co_credit.js_ file, loading the file asynchronously. Study the contents of the file and the forms and fields it contains.
