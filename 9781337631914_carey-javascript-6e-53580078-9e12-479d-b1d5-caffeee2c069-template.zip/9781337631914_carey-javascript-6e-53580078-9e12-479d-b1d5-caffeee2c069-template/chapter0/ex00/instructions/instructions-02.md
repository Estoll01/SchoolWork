## Run the Task

Every lab will contain a set of tasks that you must complete before you can Submit your assignment. Run a task by selecting the greyed-out box to the left of the Task. If you are successful, the Task box will turn green. If you are not successful, the Task box will turn red. To view the feedback, toggle the down arrow at the right of the Task box.

Try running Task 1 and Task 2 below to see what a successful and unsuccessful task would look like.
