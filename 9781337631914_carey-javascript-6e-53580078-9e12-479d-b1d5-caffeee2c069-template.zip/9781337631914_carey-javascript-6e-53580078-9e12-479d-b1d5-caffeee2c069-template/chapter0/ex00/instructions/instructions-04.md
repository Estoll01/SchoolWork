**Task 2**: This is an example task. Each task contains "checks" which are run against your code to check that the goals and the requirements for the task have been met.
