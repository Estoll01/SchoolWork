## Calculate Your Grade and Submit Your Assignment

At any time, you can select “Calculate Grade” to see what grade you have achieved so far. You can continue to work on Tasks and run the code to improve your grade.

Once you’re satisfied with your grade, you are ready to submit your assignment.

Select “Submit” to notify your instructor that you have completed the pre-requisite assignment.
