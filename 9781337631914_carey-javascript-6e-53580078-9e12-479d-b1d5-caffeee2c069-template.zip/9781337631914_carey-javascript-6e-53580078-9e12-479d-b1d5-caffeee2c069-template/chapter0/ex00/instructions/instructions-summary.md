## Summary

In this assignment, you will be cutting and pasting text from the Companion to the text editor and seeing how it displays on a webpage. Your completed assignment should look like this figure (Figure 1.1)

<img src='../assets/qwA3oWn7PGb0pRvP0VG1.png' alt='The image displays a dark blue background with two elements: a rectangular orange box centered horizontally near the top of the image and a line of text below. The orange box has a black double border and contains the text "Welcome to your course" in bold white font. Below the box, slightly to the left, is the text "What will you learn?" in a smaller white font.' />

<sup>Figure 1.1</sup>
