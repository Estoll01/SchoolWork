## Document Setup

Locate the documents and files you’ll need to successfully complete the assignment. These files are located in the “Explorer” panel of your Codespace.

<img src='../assets/u07p4pfuf7aHI8UT4fY7.png' 
     alt="The image shows a section of a file explorer in a code editing environment. Inside the directory, two files are visible: example.html, represented with an orange HTML icon, and styles.css, represented with a blue hash symbol icon." />

Select _example.html_ from the Explorer panel. It will open as a new tab in the Companion tab. Toggle back and forth between the two tabs as you work.
