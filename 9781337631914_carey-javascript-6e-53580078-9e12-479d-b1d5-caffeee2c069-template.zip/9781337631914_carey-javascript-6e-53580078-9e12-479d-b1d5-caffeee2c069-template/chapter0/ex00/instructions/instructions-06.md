**Task 3:** Copy the text from the instructions and paste it in the _example.html_ file.
