Open the _pc_cword.html_ file in your browser. Verify your solution by doing the following:

- Navigate through the puzzle using the arrow keys, Tab key, and Enter key

- Select a puzzle cell using the mouse

- Confirm that the across cells and across numbered clue for the selected cell are highlighted in blue and the down cells and down numbered clue are highlighted in red

- Press the spacebar or click the direction image to verify that the typing direction and image toggles between right and down and that the color of the active cell indicates the typing direction

- Delete the current letter by either pressing the Delete key or the Backspace key

- Briefly highlight puzzle mistakes by clicking the Show Errors button

- View the complete solution by clicking the Show Solution button
