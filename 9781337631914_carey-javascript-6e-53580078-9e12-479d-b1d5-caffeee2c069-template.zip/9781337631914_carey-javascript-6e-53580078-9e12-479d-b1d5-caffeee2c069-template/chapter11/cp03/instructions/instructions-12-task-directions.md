## Task 12

Complete the `init()` function by adding an `onclick` event handler to the "Show Solution" button. In response to the `click` event, run an anonymous function containing a `for` loop that goes through all items in the `allLetters` collection, setting the text content of each item to the value of the letter’s `dataset.letter` property.
