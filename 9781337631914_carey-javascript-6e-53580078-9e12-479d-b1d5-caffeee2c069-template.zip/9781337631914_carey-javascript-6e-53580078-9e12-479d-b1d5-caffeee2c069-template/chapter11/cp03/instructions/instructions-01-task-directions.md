Open the _pc_cword_txt.html_ and _pc_cword_txt.js_ files. Enter **your name** and **the date** in the comment section of each file, and rename them as _pc_cword.html_ and _pc_cword.js_ respectively.

## Task 01

Go to the _pc_cword.html_ file in your editor. Link the file to the _pc_cword.css_ file containing the styles for the crossword puzzle table and clues list. Asynchronously load the script from the _pc_cword.js_ file.

Take some time to study the contents of the table. Note the values of the different `data-*` attributes used to identify the different span elements of the crossword puzzle and note the IDs of the puzzle letters and the puzzle clues.
