**Task #11:** Add an `onclick` handler to the "Show Errors" button
