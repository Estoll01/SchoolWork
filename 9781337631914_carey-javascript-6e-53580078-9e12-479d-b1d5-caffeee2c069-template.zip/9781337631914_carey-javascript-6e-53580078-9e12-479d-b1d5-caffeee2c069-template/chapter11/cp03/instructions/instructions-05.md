**Task #05:** Create the `formatPuzzle()` function
