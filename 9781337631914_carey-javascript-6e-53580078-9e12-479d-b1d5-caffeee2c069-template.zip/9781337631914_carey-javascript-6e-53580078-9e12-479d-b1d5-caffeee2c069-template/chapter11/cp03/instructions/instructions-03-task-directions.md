## Task 03

Add a command to run the `init()` function when the page loads.
