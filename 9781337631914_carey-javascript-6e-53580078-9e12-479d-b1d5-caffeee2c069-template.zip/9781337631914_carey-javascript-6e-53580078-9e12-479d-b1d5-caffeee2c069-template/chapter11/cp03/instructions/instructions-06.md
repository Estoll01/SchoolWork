**Task #06:** Add to the `init()` function
