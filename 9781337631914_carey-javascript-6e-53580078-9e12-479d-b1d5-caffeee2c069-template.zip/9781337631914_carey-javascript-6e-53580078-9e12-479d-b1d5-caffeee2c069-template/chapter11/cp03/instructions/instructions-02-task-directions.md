## Task 02

Return to the _pc_cword.js_ file in your editor. Below the initial comment section, declare the following global variables:

- `allLetters`, which will be used to reference all letters in the crossword puzzle
- `currentLetter`, which will be used to reference the letter currently selected in the puzzle
- `wordLetters`, which will be used to reference the letters used in the currently selected across and down clues
- `acrossClue`, which will be used to reference the across clue currently selected in the puzzle
- `downClue`, which will be used to reference the down clue currently selected in the puzzle
- `typeDirection`, which stores the current typing direction (either to the right or down); set its initial value to **“right”**
