## Task 08

Return to the `init()` function and add an event handler to run the `selectLetter()` function in response to the `onkeydown` event occurring within the document.
