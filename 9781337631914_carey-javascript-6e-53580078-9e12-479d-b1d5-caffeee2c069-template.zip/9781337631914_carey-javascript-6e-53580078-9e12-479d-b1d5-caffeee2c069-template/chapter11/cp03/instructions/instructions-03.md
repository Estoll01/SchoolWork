**Task #03:** Set the `onload` window property to `init`
