## Task 10

Users can change the typing direction either by using the keyboard or by clicking the pointer on an image located below the crossword puzzle. Return to the `init()` function and add the following commands:

- Declare the variable `typeImage` referencing the element with the `ID` `“directionImg”`.

- Change the cursor style of type Image to **“pointer”**.

- Run the `switchTypeDirection()` function when the `typeImage` is clicked
