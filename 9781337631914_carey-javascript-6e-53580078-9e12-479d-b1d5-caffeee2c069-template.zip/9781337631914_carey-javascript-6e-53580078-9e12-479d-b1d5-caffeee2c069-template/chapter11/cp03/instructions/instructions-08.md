**Task #08:** Set `document` `onkeydown` event to run `selectLetter` function
