Use your editor to open the _bw_review_txt.html_ and _bw_review_txt.js_ files. Enter **your name** and **the date** in the comment section of each file, and rename them as _bw_review.html_ and _bw_review.js_ respectively.

## Task 01

Open _bw_review.html_ file. Go to the document head and add a `script` element for the _bw_review.js_ file. Load the file asynchronously.
