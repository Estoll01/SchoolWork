Take some time to study the contents of the file, paying close attention to the form elements and their IDs. Save your changes to the file.

## Task 02

Return to the _bw_review.js_ file in your editor. Directly after the initial comment section, insert an event handler that runs the `init()` function when the page is loaded by the browser.
