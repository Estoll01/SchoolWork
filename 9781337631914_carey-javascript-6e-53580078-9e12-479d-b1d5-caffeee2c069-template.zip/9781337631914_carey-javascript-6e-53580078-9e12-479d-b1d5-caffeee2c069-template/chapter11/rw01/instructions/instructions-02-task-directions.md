## Task 02

Go to the _jpf_hitori.js_ file in your editor. Directly below the comment section, declare the global `allCells` variable, which you will use to store an array of the puzzle cells in the Hitori table. Do not define a value for the variable yet.
