Load _jpf_hitori.html_ in your browser.

- Verify that you can switch puzzles by clicking the Puzzle buttons at the top of the page, and that you are prompted to confirm whether you want to change your puzzle. Verify that you can view the complete solution to each puzzle by clicking the "Show Solution" button.

- Verify than you can change a cell to a gray circle by clicking the cell. Verify that you can change a cell to a solid black block by clicking the cell with the Alt key pressed down. Finally, verify that you can restore a cell to black text on a white background by clicking a previously selected cell with the Shift key pressed down.

- Verify that the cursor changes shape as you move the mouse pointer over the puzzle cells, changing from a circular cursor to a block cursor when the Alt key is pressed or to an eraser cursor when the Shift key is pressed.

- Verify that you can test for errors by clicking the "Check Solution" button, and that your errors are displayed in a red font for one second.

- Solve the first puzzle using the solution provided in _Figure 11-51_. Verify that you receive a congratulatory message upon successfully completing the puzzle.
