Open the _jpf_hitori_txt.html_ and _jpf_hitori_txt.js_ files. Enter **your name** and **the date** in the comment section of each file, and rename them as _jpf_hitori.html_ and _jpf_hitori.js_ respectively.

## Task 01

Go to the _jpf_hitori.html_ file in your editor. Directly above the closing `</head>` tag, link the page to the _jpf_hitori.css_ style sheet and to the _jpf_grids3.js_ and _jpf_hitori.js_ JavaScript files. Load both JavaScript files asynchronously. Take some time to study the contents of the HTML file and then close it, saving your changes.
