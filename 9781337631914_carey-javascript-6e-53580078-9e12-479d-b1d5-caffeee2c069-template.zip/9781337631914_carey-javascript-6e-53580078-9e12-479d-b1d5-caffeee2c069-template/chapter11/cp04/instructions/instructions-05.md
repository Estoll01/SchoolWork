**Task #05:** Correct behavior when a match is found
