**Task #02:** Store the return value from `drawWordSearch(letterGrid, wordGrid)` in the `innerHTML` of the element with id "wordTable"
