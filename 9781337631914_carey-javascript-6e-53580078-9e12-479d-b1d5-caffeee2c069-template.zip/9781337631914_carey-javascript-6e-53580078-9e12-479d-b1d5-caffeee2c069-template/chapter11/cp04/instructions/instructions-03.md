**Task #03:** Store the return value from `showList(wordArray)` into the element with id "wordList"
