**Task #07:** Mouse pointer displayed using pointer icon
