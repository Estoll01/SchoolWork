Open the _kg_search_txt.html_ and _kg_search_txt.js_ files. Enter **your name** and **the date** in the comment section of each file, and save them as _kg_search.html_ and _kg_search.js_ respectively.

## Task 01

Link the _kg_search.html_ file to the _kg_search.css_ style sheet file and to the _kg_maketable.js_ and _kg_search.js_ JavaScript files. Load both JavaScript files asynchronous. Save your changes to the file.
