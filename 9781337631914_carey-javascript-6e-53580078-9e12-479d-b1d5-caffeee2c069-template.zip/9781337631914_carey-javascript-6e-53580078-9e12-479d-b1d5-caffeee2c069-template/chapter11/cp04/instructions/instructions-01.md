**Task #01:** Linked and loaded files correctly
