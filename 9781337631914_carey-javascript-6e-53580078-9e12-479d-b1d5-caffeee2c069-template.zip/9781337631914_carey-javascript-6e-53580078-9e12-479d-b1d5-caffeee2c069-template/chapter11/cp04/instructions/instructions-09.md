**Task #09:** "Show Solution" button changes the background color of words in the word search
