**Task #06:** Correct behavior when no match is found
