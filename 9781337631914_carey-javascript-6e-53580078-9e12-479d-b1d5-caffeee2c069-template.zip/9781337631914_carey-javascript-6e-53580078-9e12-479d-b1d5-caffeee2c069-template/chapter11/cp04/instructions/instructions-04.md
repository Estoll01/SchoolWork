**Task #04:** Cell background color and `pickedLetter` input box are updated when the mouse pointer is pressed down and moved over table cells
