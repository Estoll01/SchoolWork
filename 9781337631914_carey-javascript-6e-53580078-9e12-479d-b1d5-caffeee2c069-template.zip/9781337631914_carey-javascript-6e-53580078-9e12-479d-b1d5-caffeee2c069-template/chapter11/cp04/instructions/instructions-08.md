**Task #08:** Alert dialog box is shown when all words are found
