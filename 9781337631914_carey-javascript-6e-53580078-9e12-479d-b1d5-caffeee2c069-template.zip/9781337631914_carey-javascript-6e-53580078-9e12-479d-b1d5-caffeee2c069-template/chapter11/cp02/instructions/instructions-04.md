**Task #04:** Create the `buttonClick()` function
