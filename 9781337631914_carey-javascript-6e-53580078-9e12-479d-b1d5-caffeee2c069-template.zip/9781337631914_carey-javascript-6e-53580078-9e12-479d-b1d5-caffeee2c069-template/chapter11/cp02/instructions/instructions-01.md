**Task #01:** Linked and loaded files correctly in _mt_calc.html_
