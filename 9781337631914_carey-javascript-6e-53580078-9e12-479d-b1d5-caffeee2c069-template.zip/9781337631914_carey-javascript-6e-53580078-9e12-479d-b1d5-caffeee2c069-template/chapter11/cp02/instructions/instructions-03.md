**Task #03:** Create the `init()` function
