Open the _mt_calc_txt.html_ and _mt_calc_txt.js_ files. Enter **your name** and **the date** in the comment section of each file, and rename them as _mt_calc.html_ and _mt_calc.js_ respectively.

## Task 01

Go to the _mt_calc.html_ file in your editor. In the head section, create a link to the _mt_calc.css_ style sheet. Add a script element for the _mt_calc.js_ file, loading the file asynchronously.
