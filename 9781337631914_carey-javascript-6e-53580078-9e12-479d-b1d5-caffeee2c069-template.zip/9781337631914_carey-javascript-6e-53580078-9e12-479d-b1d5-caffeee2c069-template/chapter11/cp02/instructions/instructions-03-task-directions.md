## Task 03

Create the `init()` function, which sets up the event handlers for the page. Within the `init()` function, add the following commands:

- Declare the `calcButtons` variable containing the collection of page elements belonging to the calcButton class.

- Loop through the `calcButtons` object collection and, for each button in that collection, run the `buttonClick()` function in response to the `click` event.

- After the `for` loop, add a command that runs the `calcKeys()` function in response to the `keydown` event occurring within the element with the `ID` “calcWindow”.
