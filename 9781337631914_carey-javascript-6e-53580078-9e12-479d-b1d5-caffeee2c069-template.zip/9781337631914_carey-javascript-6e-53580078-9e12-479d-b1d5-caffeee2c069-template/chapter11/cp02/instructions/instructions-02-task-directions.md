## Task 02

Return to the *mt_calc.js* file in your editor. Directly below the initial comment section, insert a command that runs the `init()` function when the page is loaded by the browser.