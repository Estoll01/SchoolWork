## Task 02

Go to the _ag_cards2.js_ file in your editor. Bob has already created an object literal for the `squareGame` object containing the `cardGrid` array for storing five poker hands and two methods: the `calcRowPoints()` method for `calculating` the point total for a poker hand in a row indicated by an index argument, and the `calcColumnPoints()` method for calculating the point total for a poker hand in a column indicated by an index. Complete the `squareGame` object by adding the following properties and methods (make sure you separate the properties and methods with a comma.)

- The `gameTotal` property of the `squareGame` variable, which stores the total points achieved in the Poker Squares game. Set its value to **0**.

- The `winTotal` property of the `squareGame` variable, which stores the point total required for winning the game. Set its value to **50**.

- The `gameResult()` method, which returns the text string “Winner” if `gameTotal` is greater than or equal to `winTotal`; otherwise returns the text string “No Winner”.
