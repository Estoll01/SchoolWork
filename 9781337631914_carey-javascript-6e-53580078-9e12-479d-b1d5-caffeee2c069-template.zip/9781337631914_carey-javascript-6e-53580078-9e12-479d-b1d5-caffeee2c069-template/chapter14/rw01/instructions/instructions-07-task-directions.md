## Task 07

Change the `src` attribute of the `newCard` inline image by calling the `cardImage()` method for the `myStarterCard` object.
