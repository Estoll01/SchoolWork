**Task #09:** `onclick` event handler of the event target to **null** to prevent the user from re-clicking the cell later in the game.
