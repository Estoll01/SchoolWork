Open the _ag_squares_txt.html_, _ag_squares_txt.js_, and _ag_cards2_txt.js_ files. Enter **your name** and **the date** in the comment section of each file, and save them as _ag_squares.html_, _ag_squares.js_, and _ag_cards2.js_ respectively.

## Task 01

Go to the _ag_squares.html_ file in your editor. Link the page to the _ag_card2.js_ and _ag_squares.js_ files in that order, loading the files asynchronously. Take some time to study the HTML code in the file and then close it, saving your changes.
