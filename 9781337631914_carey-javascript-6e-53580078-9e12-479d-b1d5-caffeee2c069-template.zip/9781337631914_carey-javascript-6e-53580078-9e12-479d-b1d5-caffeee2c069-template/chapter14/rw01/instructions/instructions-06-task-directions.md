## Task 06

Create a new `pokerCard` object named `myStarterCard`. Apply the `shift()` method to the cards array of `myDeck` to store the first card from the deck in `myStarterCard`.
