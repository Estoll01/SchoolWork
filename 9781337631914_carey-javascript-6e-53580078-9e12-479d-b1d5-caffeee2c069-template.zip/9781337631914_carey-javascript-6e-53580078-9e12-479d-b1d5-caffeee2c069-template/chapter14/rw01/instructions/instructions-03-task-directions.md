## Task 03

Below the `squareGame` object, insert code for the `insertCard()` method of the `pokerHand` object prototype. The purpose of this method is to insert a card into a poker hand at a specified index. The method has two arguments: the `card` argument referencing a `pokerCard` object and the `index` argument specifying the location where the card should be placed. Insert a command into the function to make `this.
cards[index]` equal to the value of the `card` argument.
