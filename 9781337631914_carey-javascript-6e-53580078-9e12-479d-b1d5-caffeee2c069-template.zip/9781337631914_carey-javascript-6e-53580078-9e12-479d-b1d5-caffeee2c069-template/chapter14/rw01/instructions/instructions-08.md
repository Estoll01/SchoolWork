**Task #08:** `onclick` event handler for cells in the grid table inserts a new card into the grid cell
