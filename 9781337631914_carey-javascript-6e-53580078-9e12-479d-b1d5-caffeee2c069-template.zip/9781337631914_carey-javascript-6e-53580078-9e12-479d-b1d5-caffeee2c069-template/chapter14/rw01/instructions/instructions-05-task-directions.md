## Task 05

Create a new `pockerDeck` object named `myDeck` and use the `shuffle()` method to randomize the order of its cards.
