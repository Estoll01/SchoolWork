Open the _ag_squares.html_ file in your browser. Click the Start button to begin a game. Verify that you can add cards to the grid by clicking cells within the table. Play a complete game by filling out the grid and verify that when all cells are filled, the page displays:

- row and column totals for every hand,
- the overall point total for the game,
- a message indicating whether the player won or lost, and
- a card image showing that the game is over.
