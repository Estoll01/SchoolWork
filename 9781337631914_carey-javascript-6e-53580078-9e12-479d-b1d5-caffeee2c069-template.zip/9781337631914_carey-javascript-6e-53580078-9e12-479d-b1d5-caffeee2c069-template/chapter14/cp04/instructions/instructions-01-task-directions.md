Open the _kg_stamps_txt.html_ and _kg_stamps_txt.js_ files. Enter **your name** and **the date** in the comment section of each file, and rename them as _kg_stamps.html_ and _kg_stamps.js_ respectively.

## Task 01

Go to the _kg_stamps.html_ file in your editor. Link the file to the _kg_stamps.js_ file, loading that file asynchronously.
