Take some time to study the content and structure of the _kg_stamps.html_ file, becoming familiar with the page elements, their classes, and their IDs.

Go to the _kg_stamps.js_ file in your editor. Write code that will satisfy the conditions that Pete has given you for the final application. Comment your work throughout, documenting all objects, properties, and methods you created for this project.
