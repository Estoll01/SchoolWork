## Task 04

Users can search for names in three ways:

- Matching an employee’s last name if it contains the text string specified in nameSearch,
- Matching an employee’s last name if it begins with the nameSearch text string, and
- Matching an employee’s last name only if it exactly matches the nameSearch text string.

Richard has supplied you with code to add the `selectedValue()` method to the prototype of the `HTMLSelectElement` object class in order to return the value of the selected option in any selection list.

Apply the `selectedValue()` method to the `nameSearchType` selection list to return the option selected by the user, storing the value in the `nameSearchType` variable.
