**Task #02:** `onclick` event handler removes child nodes from `tableBody` variable and clears previous search results
