## Task 03

Erase previous search results by setting the employees array of the `searchResult` object to the empty array [].

Next, you will write the code that returns the employee records that match search conditions set by the user. Apply the `forEach()` array method to loop through the contents of the directory array in the staff object. For each employee object in the directory array, run an anonymous function with the parameter, record, that represents each record in the array.

Create the `nameSearch` variable equal to the value entered in the `nameSearch` input box.
