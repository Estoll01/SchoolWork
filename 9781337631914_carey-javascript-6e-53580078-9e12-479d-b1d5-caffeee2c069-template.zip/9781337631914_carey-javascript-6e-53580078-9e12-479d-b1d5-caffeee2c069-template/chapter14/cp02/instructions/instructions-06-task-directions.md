## Task 06

Using `nameRegExp` as the regular expression, apply the `test()` method to the `record.Lastname` property (the last name stored in the employee record currently being examined in the `forEach()` loop). Store the results of the `test()` method in the `foundName` variable.
