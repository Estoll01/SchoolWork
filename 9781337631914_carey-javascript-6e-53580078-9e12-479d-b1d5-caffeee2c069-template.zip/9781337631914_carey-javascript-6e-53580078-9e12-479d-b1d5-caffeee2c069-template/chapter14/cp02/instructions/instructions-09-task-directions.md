## Task 09

For an employee record to be displayed in the staff table, it must match the search condition set by the user. Insert an `if` statement that tests whether `foundName`, `foundPosition`, and `foundDept` are all `true`. If so, use the `push()` method to add a new `employee` object to the `employees` array in the `searchResult` object.

> Hint: use `record.id`, `record.firstName`, `record.lastName`, and so on as the parameter values in the new `employee()` statement.
