Use your editor to open the _cc_staff_txt.html_ and _cc_staff_txt.js_ files. Enter **your name** and **the date** in the comment section of each file, and rename them as _cc_staff.html_ and _cc_staff.js_ respectively.

## Task 01

Go to the _cc_staff.html_ file in your editor. Within the document head, add `script` elements for the _cc_data.js_ and _cc_staff.js_ files in that order. Load the files asynchronously. Take some time to study the contents of the file and then close it, saving your changes.
