## Task 07

Repeat Task 03 through Task 06 to determine whether the employee’s position property matches the value entered into the `positionSearch` input box on the web form. Store the value of the `positionSearch` input box in the `positionSearch` variable, the type of search in the `positionSearchType` variable, the regular expression in the `positionRegExp` variable, and the result of the regular expression test in the `foundPosition` variable.
