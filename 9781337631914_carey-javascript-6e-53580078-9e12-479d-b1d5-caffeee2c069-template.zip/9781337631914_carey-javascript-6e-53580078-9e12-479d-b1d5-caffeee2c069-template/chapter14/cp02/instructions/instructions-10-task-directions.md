## Task 10

After the `forEach` loop has finished and the `employees` array in the `searchResult` object contains all of the employee records matching the user’s search conditions, change the text content of the `tableCaption` object to “total records found” where total is the value of the length of the employees array in the `searchResult` object.
