## Task 11

Apply the `sortById()` method to the `searchResult` object, which will sort the content of the employees array by the employee ID number.
