## Task 08

Have both the `pizza` and `topping` object class inherit the properties and methods of any food item by making their prototypes instances of the `foodItem` object.
