## Task 04

Create a constructor for the `foodItem` object class. Add two properties to the class: the `price` property storing the price of the food item, and the `qty` property storing the quantity of the food item ordered. Do not specify a value for the properties.
