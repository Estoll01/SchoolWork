## Task 10 and Task 11

Now that you’ve defined the custom objects for ordering pizzas, scroll down to the event listener for the load event. Alice has already nested the `buildPizza()` and `addPizzaToCart()` functions in the event listener but you will have to complete these functions to create a working shopping cart page. Directly before the `buildPizza()` function, insert the following commands:

- Declare the `myCart` variable as an instance of a `cart` object.

- Run the `addPizzaToCart()` function when the `addToCartButton` form button is clicked.
