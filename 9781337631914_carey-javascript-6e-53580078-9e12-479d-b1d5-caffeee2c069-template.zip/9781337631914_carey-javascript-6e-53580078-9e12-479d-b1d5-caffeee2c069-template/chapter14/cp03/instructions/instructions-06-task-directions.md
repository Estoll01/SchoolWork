## Task 06

Create the following constructors for pizzas and toppings on pizzas:

- Create a constructor for the `pizza` object class. Add the following properties to the class: `size` (for the size of the pizza), `crust` (for the crust style), `doubleSauce` and `doubleCheese` (to indicate whether pizza has double sauce or double cheese), and the `toppings` property (for storing the array of topping items on the pizza). Do not set an initial value for the `size`, `crust`, `doubleSauce`, or `doubleCheese` properties. Set toppings to an empty array.

- Create a constructor for the `topping` object class. Add the `name` property for storing the name of the topping, and the `side` property for recording whether the topping should be across the full pizza, or only on the left or right side. Do not set an initial value for either property.
