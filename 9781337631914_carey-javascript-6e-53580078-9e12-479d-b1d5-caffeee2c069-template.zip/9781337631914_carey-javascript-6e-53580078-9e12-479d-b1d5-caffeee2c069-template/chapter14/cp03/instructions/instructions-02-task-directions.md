Take some time to study the elements in the web form, noting the IDs and classes associated with each element. Save your changes to the file and then go to the _rb_build.js_ file in your editor.

## Task 02

Directly below the initial comment section, create an object literal named `pizzaPrice` that will store the price of individual pizza components. Add the following properties and values to the object literal:

- `size12` with a value of **11**, `size14` with a value of **13**, and `size16` with a value of **16** (the prices of 12", 14", and 16" pizzas)

- `stuffed` with a value of **3** and `pan` with a value of **2** (the additional price of stuff-crust and pan-style pizzas)

- `doubleSauce` with a value of **1.5**, `doubleCheese` with a value of **1.5**, and `topping` with a value of **1.5** (the prices for double sauce, double cheese, and additional pizza toppings.)
