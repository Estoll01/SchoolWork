Open the _rb_pizza_txt.html_ and _rb_build_txt.js_ files. Enter **your name** and **the date** in the comment section of each file, and save them as _rb_pizza.html_ and _rb_build.js_ respectively.

## Task 01

Go to the _rb_pizza.html_ file in your editor. Link the file to the _rb_build.js_ file, loading that file asynchronously.
