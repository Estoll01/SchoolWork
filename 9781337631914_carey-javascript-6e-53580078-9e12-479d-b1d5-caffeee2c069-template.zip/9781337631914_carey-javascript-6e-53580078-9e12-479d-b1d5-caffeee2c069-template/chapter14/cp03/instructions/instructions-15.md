**Task #15:** Function `addPizzaToCart()` calls `resetDrawPizza()`
