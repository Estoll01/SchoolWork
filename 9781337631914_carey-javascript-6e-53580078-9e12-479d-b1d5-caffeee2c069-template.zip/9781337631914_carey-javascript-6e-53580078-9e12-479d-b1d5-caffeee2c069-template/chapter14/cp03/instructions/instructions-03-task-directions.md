## Task 03

Create a constructor function for the `cart` object class. The `cart` object class has two properties: the `totalCost` property, which stores the total cost of the items in the cart and the `items` array, which stores the items in the cart. Set the initial value of the `totalCost` property to **0** and set the items property to an empty array.
