## Task 15

Call the `resetDrawPizza()` function to restore the web form controls to their original appearances.
