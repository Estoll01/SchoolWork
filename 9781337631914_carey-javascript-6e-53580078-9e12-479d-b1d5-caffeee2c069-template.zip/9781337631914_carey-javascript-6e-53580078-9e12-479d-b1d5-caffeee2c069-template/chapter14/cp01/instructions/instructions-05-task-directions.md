## Task 05

After the bubble constructor function, create the following methods for the bubble prototype:

- The `fadeBubble()` method that causes the bubble to fade by reducing its opacity. Insert a command to decrease the value of the bubble’s opacity property by **0.0005**.

- The `changeColor()` method that changes the hue of the bubble. Insert a command that increases the value of the bubble’s hue property by **3** and then calculates the remainder by dividing that sum by **360**, storing the result in the hue property.

> Hint: Use the `%` operator described in _Figure 9-24_ to calculate the remainder.

- The `rotateBubble()` that rotates the bubble. Insert a command that increases the value of the rotate property by the value of the `rotateDirection` property and then calculate the remainder by dividing that sum by **360**, storing the result in the rotate property.

> Hint: Once again use the `%` operator.
