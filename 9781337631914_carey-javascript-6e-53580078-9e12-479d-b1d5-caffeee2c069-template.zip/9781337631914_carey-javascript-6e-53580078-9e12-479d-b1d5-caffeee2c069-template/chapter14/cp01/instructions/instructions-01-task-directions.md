Open the _bu_home_txt.html_ and _bu_bubbles_txt.js_ files. Enter **your name** and **the date** in the comment section of each file, and rename them as _bu_home.html_ and _bu_bubbles.js_ respectively.

## Task 01

Go to the _bu_bubbles.html_ file in your editor. Within the document head, add a `script` element for the _bu_bubbles.js_ file. Load the file asynchronously.
