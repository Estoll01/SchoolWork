## Task 02

Scroll down to the section element with the ID “logosection” and insert a div element with the ID “bubbleBox” in which you will display the bubble images.
