## Task 03

Save your changes and go to the _bu_bubbles.js_ file in your editor. Directly below the comment section, create an object literal for the `box` object. Add the following properties to the object: the `width` property with a value **1024** that defines the width of the box containing the bubbles, and the `height` property with a value of **500** defining the box’s height.
