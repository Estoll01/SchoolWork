## Task 09

Next, you will create an inline image displaying the bubble image within the bubble box. Add the following commands to create the bubble image:

- Create an `img` element named `bubbleImg` with its `position` property set to `absolute`.

- Set the `src` property of `bubbleImg` to the value of the `imageURL` property of the `newBubble` object.

- Set the `width` style of `bubbleImg` to `radiuspx`, where radius is the value of the `radius` property of `newBubble`.

- Set the `left` and `top` styles of `bubbleImg` to `xPos`px and `yPos`px respectively, where xPox and yPos are the values of the `xPos` and `yPos` properties of `newBubble`.

- Append `bubbleImg` to the `bubbleBox` element.
