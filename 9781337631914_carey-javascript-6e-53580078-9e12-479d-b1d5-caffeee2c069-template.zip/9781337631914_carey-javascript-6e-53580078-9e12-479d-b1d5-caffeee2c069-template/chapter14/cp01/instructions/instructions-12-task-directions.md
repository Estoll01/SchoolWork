## Task 12

If the `opacity` property of `newBubble` is less than 0, remove the bubble by:

- Removing bubbleImg element from bubbleBox.

- Applying the `clearInterval()` method to stop the animation effects for the bubble, using `bubbleInterval` as the ID of the repeated command.
