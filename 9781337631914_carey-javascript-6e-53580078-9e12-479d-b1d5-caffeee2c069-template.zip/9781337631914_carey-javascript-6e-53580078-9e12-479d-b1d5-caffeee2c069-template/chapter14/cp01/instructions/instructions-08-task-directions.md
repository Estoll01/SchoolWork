## Task 08

Define the following property values for the `newBubble` object:

- Set the `xPos` and `yPos` properties to half of the `box.width` and `box.height` properties respectively, placing the new bubble in the center of the bubble box.

- Set the `xVelocity` and `yVelocity` properties to a random integer between 5 and 5.

- Set the `rotate` and `hue` properties to a random integer between 0 and 360.

- Set the `rotateDirection` property to a random integer between 2 and 2.
