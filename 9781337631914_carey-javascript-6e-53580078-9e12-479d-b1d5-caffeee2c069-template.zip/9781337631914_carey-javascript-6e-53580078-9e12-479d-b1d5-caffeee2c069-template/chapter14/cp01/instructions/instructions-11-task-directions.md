## Task 11

Apply the `fadeBubble()` method to the `newBubble` object to decrease the bubble’s opacity.
