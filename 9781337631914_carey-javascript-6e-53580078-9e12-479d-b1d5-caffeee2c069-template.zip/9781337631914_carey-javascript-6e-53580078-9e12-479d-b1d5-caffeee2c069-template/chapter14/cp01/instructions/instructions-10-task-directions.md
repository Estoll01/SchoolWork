## Task 10

Now, that you’ve created the bubble image, you will insert commands to animate its appearance. Within the `if` statement, add a `setInterval()` method that repeats an anonymous function every 25 milliseconds, storing the ID of the `setInterval()` method in the `bubbleInterval` variable.
