## Task 04

Create an object constructor function for the `bubble` class of objects. Include two arguments with the function: the `size` argument specifying the radius of the bubble, and the `img` property specifying the URL of the image file of the bubble image. Add the following properties to the bubble object class:

- The `radius` property, setting it to the value of the `size` argument.

- The `imageURL`, setting it to the value of the `img` argument.

- The `xVelocity` property, storing the horizontal velocity of the bubble and the `yVelocity` property storing the vertical velocity. Set both values to **null**.

- The `xPos` property, storing the horizontal position of the bubble and the `yPos` property storing the vertical position. Set both values to **null**.

- The `opacity` property, storing the bubble’s opacity. Set its value to **1**.

- The `hue` property, storing the bubble’s hue value. Set its value to **0**.

- The `rotate` property, storing the speed of the bubble’s spin. Set its value to **0**.

- The `rotateDirection` property, storing the direction in which the bubble spins. Set its value to **1**.
